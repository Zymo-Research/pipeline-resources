This test dataset is for use with bulk RNAseq pipeline on Aladdin Bionformatics.
The dataset originally came from this publication: https://pubmed.ncbi.nlm.nih.gov/26952870/
The original dataset was randomly subsampled to 100K read pairs per sample.

When using this dataset on Aladdin Bioinformatics, please:
1. Upload the FASTQ files.
2. Choose RNAseq as sample type.
3. Choose RNAseq pipeline. Choose GRCh37 or GRCh38 as genome. Choose Illumina kits as protocol. Assign group labels if you wish.
